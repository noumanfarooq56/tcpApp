﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.Threading;
using System.Collections.Generic;

using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Newtonsoft.Json;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private Socket _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        byte[] receivedBuf = new byte[1024];
        Thread thr;
        appstructconst appstructobj;
        public Form1()
        {
            InitializeComponent();
        }
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern IntPtr FindWindow(String lpClassName, String lpWindowName);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool ShowWindow(IntPtr handle, int nCmdShow);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool IsIconic(IntPtr handle);        
        void getprocessesList()
        {    
            //uint[] processids =new uint[100];
            //string[] processnames = new string[100];
            //uint[] threadids = new uint[100];
            //IntPtr []handlelist = new IntPtr[100];
            int i = 1;
            foreach (KeyValuePair<IntPtr, string> window in OpenWindowGetter.GetOpenWindows())
            {
                IntPtr handle = window.Key;
                string title = window.Value;
                Console.WriteLine("{0}: {1} :{2}",i, handle, title);
                uint processid = 0;
                uint threadid = GetWindowThreadProcessId((IntPtr)handle, out processid);
                //processids[i] = processid;
                //processnames[i] = title;
                //threadids[i] = threadid;
                //handlelist[i] = handle;
                i++;
                string[] prcdetails = new string[] { handle.ToString(),title,processid.ToString(),threadid.ToString() };
                ListViewItem proc = new ListViewItem(prcdetails);
                
                appstructobj.listprocs.Add(prcdetails);
               // listprocs.Add(prcdetails);
                Processlist.Items.Add(proc);
                //                
            }
        
        
        }
        public void getProcessListforServer()
        {
            int i = 1;
            foreach (KeyValuePair<IntPtr, string> window in OpenWindowGetter.GetOpenWindows())
            {
                IntPtr handle = window.Key;
                string title = window.Value;
                Console.WriteLine("{0}: {1} :{2}", i, handle, title);
                uint processid = 0;
                uint threadid = GetWindowThreadProcessId((IntPtr)handle, out processid);
                //processids[i] = processid;
                //processnames[i] = title;
                //threadids[i] = threadid;
                //handlelist[i] = handle;
                i++;
                string[] prcdetails = new string[] { handle.ToString(), title, processid.ToString(), threadid.ToString() };
                ListViewItem proc = new ListViewItem(prcdetails);

                appstructobj.listprocs.Add(prcdetails);
                // listprocs.Add(prcdetails);
               // Processlist.Items.Add(proc);
                //                
            }
        }
        public void bringprocesstofrontfunc(string text)
        {
            appstructobj = new appstructconst();
            int sw_windowmacro = 9;
            try
            {
                    int userVal = int.Parse(text);
                    IntPtr handle = new IntPtr(userVal);
                    if (IsIconic(handle))
                    {
                        ShowWindow(handle, sw_windowmacro);
                    }
                    SetForegroundWindow(handle);

                    Processlist.Items.Clear();
                    getprocessesList();
              }
            catch (Exception ex)
            {
             //   MessageBox.Show("please select a process");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            appstructobj = new appstructconst();
            int sw_windowmacro = 9;
            try
            {
                String text = Processlist.SelectedItems[0].Text;
                if (text != "")
                {
                    int userVal = int.Parse(text);
                    IntPtr handle = new IntPtr(userVal);
                    if (IsIconic(handle))
                    {
                        ShowWindow(handle, sw_windowmacro);
                    }
                    SetForegroundWindow(handle);
                   
                    Processlist.Items.Clear();
                    getprocessesList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("please select a process");
            }
        }
      

        private void Form1_Load(object sender, EventArgs e)
        {

            appstructobj = new appstructconst();
            getprocessesList();
              //IntPtr x = new IntPtr(2165376);
            //SetForegroundWindow(x);
            

            //SetForegroundWindow(x);
       
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Processlist.Items.Clear();
                  
            getprocessesList();
        }
        //TCP Client getprocessesLists
        private void ReceiveData(IAsyncResult ar)
        {
            Socket socket = (Socket)ar.AsyncState;
            int received = socket.EndReceive(ar);
            byte[] dataBuf = new byte[received];
            Array.Copy(receivedBuf, dataBuf, received);
            string rec = Encoding.ASCII.GetString(dataBuf);
            //label_serverResponse.Text = rec;
            if (rec[0] != '@')
            {
                processincoming(rec);
            }
            //   rb_chat.AppendText("hey");
            //   rb_chat.AppendText("\nServer: " + Encoding.ASCII.GetString(dataBuf));
            _clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveData), _clientSocket);
        }

        private void SendLoop()
        {
            while (true)
            {
                //Console.WriteLine("Enter a request: ");
                //string req = Console.ReadLine();
                //byte[] buffer = Encoding.ASCII.GetBytes(req);
                //_clientSocket.Send(buffer);

                byte[] receivedBuf = new byte[1024];
                int rev = _clientSocket.Receive(receivedBuf);
                if (rev != 0)
                {
                    byte[] data = new byte[rev];
                    Array.Copy(receivedBuf, data, rev);
                    label_serverResponse.Text = ("Received: " + Encoding.ASCII.GetString(data));

                }
               //     rb_chat.AppendText("\nServer: " + Encoding.ASCII.GetString(data));
                else _clientSocket.Close();

            }
        }
        void processincoming(string text)
        {
            //acc to req
            
            appstructconst obj = new appstructconst();
            obj = JsonConvert.DeserializeObject<appstructconst>(text);
            if (obj.msg == "refresh")
            {
                appstructobj = new appstructconst();
                getProcessListforServer();
                string textJ = JsonConvert.SerializeObject(appstructobj);
                byte[] buffer = Encoding.ASCII.GetBytes(textJ);
                _clientSocket.Send(buffer);
           
            }
            else
            {
                bringprocesstofrontfunc(obj.msg);
                //now send the updated ones
                getProcessListforServer();
                string textJ = JsonConvert.SerializeObject(appstructobj);
                byte[] buffer = Encoding.ASCII.GetBytes(textJ);
                _clientSocket.Send(buffer);
            }
        }
        private void LoopConnect()
        {
            int attempts = 0;
            while (!_clientSocket.Connected)
            {
                try
                {
                    attempts++;
                    _clientSocket.Connect("192.168.43.88", 8888);
                }
                catch (SocketException)
                {
                    //Console.Clear();
                    label_serverResponse.Text = ("Connection attempts: " + attempts.ToString());
                }
            }
            label_serverResponse.Text = ("Connected!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoopConnect();
            // SendLoop();
            _clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveData), _clientSocket);
            byte[] buffer = Encoding.ASCII.GetBytes("@@" + Callsign.Text);
            _clientSocket.Send(buffer);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (_clientSocket.Connected)
            {
                appstructobj.callsign = "nouman";
                appstructobj.ipadd = "200.0.0.0";
                appstructobj.portno = 8888;
                
                //appstructconst.genericId enumval = appstructconst.genericId.msgsend;
                appstructobj.msg = "hi how are you";
                string text = JsonConvert.SerializeObject(appstructobj);
                byte[] buffer = Encoding.ASCII.GetBytes(text);
                _clientSocket.Send(buffer);
                //rb_chat.AppendText("Client: " + txt_text.Text);
            }
        }

    }
}
