﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server_TCP
{
    class appstructconst
    {
        public enum genericId
        {
            connection = 1,
            msgsend = 2
        }
        public enum exactId
        {
            recvConnection = 101,
            reqConnection = 102,
            sendmsg = 103
        }
        //dummy data
        public int portno;
        public string ipadd;
        public string callsign;
        public string msg;

        public List<string[]> listprocs = new List<string[]>();

    }
}
