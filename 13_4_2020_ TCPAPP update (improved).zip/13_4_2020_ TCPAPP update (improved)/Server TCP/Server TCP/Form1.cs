﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.Sockets;
using Newtonsoft.Json;
namespace Server_TCP
{
 
   
    public partial class Form1 : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern IntPtr FindWindow(String lpClassName, String lpWindowName);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool ShowWindow(IntPtr handle, int nCmdShow);
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool IsIconic(IntPtr handle);        
        
        public class SocketT2h
        {
            
            public Socket _Socket { get; set; }
            public string _Name { get; set; }
            public SocketT2h(Socket socket)
            {
                this._Socket = socket;
            }
        } 
        private byte[] _buffer = new byte[1024];
        public List<SocketT2h> __ClientSockets { get; set; }
        List<string> _names = new List<string>();
        private Socket _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            __ClientSockets = new List<SocketT2h>();
        }
        private void SetupServer()
        {
            IPAddress address = IPAddress.Parse("192.168.43.88");

            _serverSocket.Bind(new IPEndPoint(address, 8888));
            label_serverStatus.Text = "Server Started . . .";   
            _serverSocket.Listen(1);
            _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
        private void AppceptCallback(IAsyncResult ar)
        {
            Socket socket = _serverSocket.EndAccept(ar);
            __ClientSockets.Add(new SocketT2h(socket));
            list_Client.Items.Add(socket.RemoteEndPoint.ToString());

            label_clientsCount.Text = "Number of clients connected: " + __ClientSockets.Count.ToString();
            label_serverStatus.Text = "Client connected. . .";
            socket.BeginReceive(_buffer, 0, _buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallback), socket);
            _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
        }

        private void ReceiveCallback(IAsyncResult ar)
        {

            Socket socket = (Socket)ar.AsyncState;
            if (socket.Connected)
            {
                int received;
                try
                {
                    received = socket.EndReceive(ar);
                }
                catch (Exception)
                {
                    for (int i = 0; i < __ClientSockets.Count; i++)
                    {
                        if (__ClientSockets[i]._Socket.RemoteEndPoint.ToString().Equals(socket.RemoteEndPoint.ToString()))
                        {
                            __ClientSockets.RemoveAt(i);
                            label_clientsCount.Text = "Number of clients connected: " + __ClientSockets.Count.ToString();
                        }
                    }
                    return;
                }
                if (received != 0)
                {
                    byte[] dataBuf = new byte[received];
                    Array.Copy(_buffer, dataBuf, received);
                    string text = Encoding.ASCII.GetString(dataBuf);
                    int len = dataBuf.Length;
                    label_serverStatus.Text = "Text received from client: " + text;
                    if (text[0] != '@')
                    {
                      
                     
                        processIncoming(text);
                    }
                    string reponse = string.Empty;
                     
                    for (int i = 0; i < __ClientSockets.Count; i++)
                    {
                        if (socket.RemoteEndPoint.ToString().Equals(__ClientSockets[i]._Socket.RemoteEndPoint.ToString()))
                        {
                            rich_Text.AppendText("\n" + __ClientSockets[i]._Name + ": " + text);
                        }
                    }



                    //if (text == "bye")
                    //{
                    //    return;
                    //}
                    reponse =  text;
             //       Sendata(socket, reponse);
                }
                else
                {
                    for (int i = 0; i < __ClientSockets.Count; i++)
                    {
                        if (__ClientSockets[i]._Socket.RemoteEndPoint.ToString().Equals(socket.RemoteEndPoint.ToString()))
                        {
                            __ClientSockets.RemoveAt(i);
                            label_clientsCount.Text = "Number of clients connected: " + __ClientSockets.Count.ToString();
                        }
                    }
                }
            }
            socket.BeginReceive(_buffer, 0, _buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallback), socket);
        }
        void processIncoming(string text)
        {
           //according to requirment
            appstructconst obj = new appstructconst();
            obj = JsonConvert.DeserializeObject<appstructconst>(text);
            for (int i = 0; i < obj.listprocs.Count; i++)
            {
                ListViewItem proc = new ListViewItem(obj.listprocs[i]);
              
                Processlist.Items.Add(proc);
            }
        }
        void Sendata(Socket socket, string dataa)
        {
            byte[] data = Encoding.ASCII.GetBytes(dataa);
            socket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(SendCallback), socket);
            _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
        }
        private void SendCallback(IAsyncResult AR)
        {
            Socket socket = (Socket)AR.AsyncState;
            socket.EndSend(AR);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < list_Client.SelectedItems.Count; i++)
            {
                string t = list_Client.SelectedItems[i].ToString();
                for (int j = 0; j < __ClientSockets.Count; j++)
                {
                    //if (__ClientSockets[j]._Socket.Connected && __ClientSockets[j]._Name.Equals("@"+t))
                    {
                        appstructconst obj = new appstructconst();
                        obj.msg = "from server";
                        string text = JsonConvert.SerializeObject(obj);
                        Sendata(__ClientSockets[j]._Socket, text);
                    }
                }
            }
            rich_Text.AppendText("\nServer: " + txt_Text.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetupServer();
            button1.Enabled = false;
        }

        private void bringtofront_Click(object sender, EventArgs e)
        {
           
            for (int i = 0; i < list_Client.SelectedItems.Count; i++)
            {
                string t = list_Client.SelectedItems[i].ToString();
                for (int j = 0; j < __ClientSockets.Count; j++)
                {
                    String text = Processlist.SelectedItems[0].Text;
                    Processlist.Items.Clear();
                    appstructconst objj = new appstructconst();
                    objj.msg = text;
                    string textJ = JsonConvert.SerializeObject(objj);
                    Sendata(__ClientSockets[j]._Socket, textJ);
                }
            }
                   // function();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Processlist.Items.Clear();
            for (int i = 0; i < list_Client.SelectedItems.Count; i++)
            {
                string t = list_Client.SelectedItems[i].ToString();
                for (int j = 0; j < __ClientSockets.Count; j++)
                {
                    //String text = Processlist.SelectedItems[0].Text;
                    appstructconst objj = new appstructconst();

                    objj.msg = "refresh";
                    string textJ = JsonConvert.SerializeObject(objj);
                    Sendata(__ClientSockets[j]._Socket, textJ);
                }
            }

        }
    }
}
