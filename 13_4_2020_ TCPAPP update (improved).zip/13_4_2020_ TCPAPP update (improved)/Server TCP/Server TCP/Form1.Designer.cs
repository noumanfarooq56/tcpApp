﻿namespace Server_TCP
{
    partial class Form1
    {
         /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.label_serverStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.label_clientsCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.list_Client = new System.Windows.Forms.CheckedListBox();
            this.txt_Text = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.rich_Text = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Processlist = new System.Windows.Forms.ListView();
            this.Processhandle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ProcessName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Pid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ThreadID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button2 = new System.Windows.Forms.Button();
            this.bringtofront = new System.Windows.Forms.Button();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.label_serverStatus,
            this.label_clientsCount});
            this.statusStrip1.Location = new System.Drawing.Point(0, 386);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1050, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // label_serverStatus
            // 
            this.label_serverStatus.Name = "label_serverStatus";
            this.label_serverStatus.Size = new System.Drawing.Size(102, 17);
            this.label_serverStatus.Text = "Server Not Started";
            // 
            // label_clientsCount
            // 
            this.label_clientsCount.Name = "label_clientsCount";
            this.label_clientsCount.Size = new System.Drawing.Size(142, 17);
            this.label_clientsCount.Text = "No. of clients connected: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.list_Client);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(211, 229);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "List Client";
            // 
            // list_Client
            // 
            this.list_Client.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_Client.FormattingEnabled = true;
            this.list_Client.Location = new System.Drawing.Point(3, 16);
            this.list_Client.Name = "list_Client";
            this.list_Client.Size = new System.Drawing.Size(205, 210);
            this.list_Client.TabIndex = 5;
            // 
            // txt_Text
            // 
            this.txt_Text.Enabled = false;
            this.txt_Text.Location = new System.Drawing.Point(15, 247);
            this.txt_Text.Name = "txt_Text";
            this.txt_Text.Size = new System.Drawing.Size(205, 20);
            this.txt_Text.TabIndex = 3;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(237, 245);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 4;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // rich_Text
            // 
            this.rich_Text.Location = new System.Drawing.Point(229, 28);
            this.rich_Text.Name = "rich_Text";
            this.rich_Text.Size = new System.Drawing.Size(202, 210);
            this.rich_Text.TabIndex = 5;
            this.rich_Text.Text = "";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(319, 244);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Start Server";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Processlist
            // 
            this.Processlist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Processhandle,
            this.ProcessName,
            this.Pid,
            this.ThreadID});
            this.Processlist.Location = new System.Drawing.Point(461, 28);
            this.Processlist.Name = "Processlist";
            this.Processlist.Size = new System.Drawing.Size(554, 326);
            this.Processlist.TabIndex = 7;
            this.Processlist.UseCompatibleStateImageBehavior = false;
            this.Processlist.View = System.Windows.Forms.View.Details;
            // 
            // Processhandle
            // 
            this.Processhandle.Text = "Process Handles";
            this.Processhandle.Width = 115;
            // 
            // ProcessName
            // 
            this.ProcessName.Text = "Process Name";
            this.ProcessName.Width = 240;
            // 
            // Pid
            // 
            this.Pid.Text = "Pid";
            this.Pid.Width = 100;
            // 
            // ThreadID
            // 
            this.ThreadID.Text = "Thread ID";
            this.ThreadID.Width = 95;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(768, 360);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Refresh List";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // bringtofront
            // 
            this.bringtofront.Location = new System.Drawing.Point(568, 360);
            this.bringtofront.Name = "bringtofront";
            this.bringtofront.Size = new System.Drawing.Size(154, 23);
            this.bringtofront.TabIndex = 9;
            this.bringtofront.Text = "Bring process to front";
            this.bringtofront.UseVisualStyleBackColor = true;
            this.bringtofront.Click += new System.EventHandler(this.bringtofront_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 408);
            this.Controls.Add(this.bringtofront);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Processlist);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.rich_Text);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txt_Text);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel label_serverStatus;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_Text;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.CheckedListBox list_Client;
        private System.Windows.Forms.ToolStripStatusLabel label_clientsCount;
        private System.Windows.Forms.RichTextBox rich_Text;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListView Processlist;
        private System.Windows.Forms.ColumnHeader Processhandle;
        private System.Windows.Forms.ColumnHeader ProcessName;
        private System.Windows.Forms.ColumnHeader Pid;
        private System.Windows.Forms.ColumnHeader ThreadID;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button bringtofront;
    }
    
}

